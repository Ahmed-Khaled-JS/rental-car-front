function acceptRequest() {
    var consumerName = document.getElementById("consumer-name").value;
    var carNumber = document.getElementById("car-number").value;
    var numberOfDays = document.getElementById("number-of-days").value;
    alert("Your accept is successful");
}

function rejectRequest() {
    var consumerName = document.getElementById("consumer-name").value;
    var carNumber = document.getElementById("car-number").value;
    var numberOfDays = document.getElementById("number-of-days").value;
    alert("Your reject is successful");
}