

function AddCar(){

    window.location.href="/addVechile.html"

}

function showMycars(){

    window.location.href="/vehicles.html"

}

function showMyrequests(){
    window.location.href="/request.html"

}